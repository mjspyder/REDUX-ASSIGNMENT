import React, { useState } from 'react';
import InputComponent from './InputComponent';
import withUpperCase from './withUpperCase';

const EnhancedInputComponent = withUpperCase(InputComponent);

const App = () => {
  const [inputText, setInputText] = useState('');

  const handleInputChange = (text) => {
    setInputText(text);
  };

  return (
    <div>
      <h1>Input Component</h1>
      <EnhancedInputComponent onChange={handleInputChange} />
      <p>Text Capitalized: {inputText}</p>
    </div>
  );
};

export default App;
